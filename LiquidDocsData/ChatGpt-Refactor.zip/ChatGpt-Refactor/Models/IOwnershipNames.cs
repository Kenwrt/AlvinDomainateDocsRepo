﻿namespace LiquidDocsData.Models;

public interface IOwnershipNames
{
    string Name { get; }
    decimal PercentOfOwnership { get; }
}