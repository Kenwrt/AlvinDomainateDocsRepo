﻿namespace LiquidDocsData.Models;

public interface ISigningPartyNames
{
    string Name { get; }
    string Title { get; }
}