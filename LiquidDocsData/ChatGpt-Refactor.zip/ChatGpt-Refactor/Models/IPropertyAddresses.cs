﻿namespace LiquidDocsData.Models;

public interface IPropertyAddresses
{
    string FullAddress { get; }
}