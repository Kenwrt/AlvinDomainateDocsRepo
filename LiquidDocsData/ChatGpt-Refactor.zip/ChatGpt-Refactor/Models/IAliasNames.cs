﻿namespace LiquidDocsData.Models;

public interface IAliasNames
{
    string Name { get; }
    string AlsoKnownAs { get; }
}